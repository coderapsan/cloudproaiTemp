"use strict";
(() => {
var exports = {};
exports.id = 9128;
exports.ids = [9128];
exports.modules = {

/***/ 6219:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: external "mongoose"
const external_mongoose_namespaceObject = require("mongoose");
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_namespaceObject);
;// CONCATENATED MODULE: ./utils/dbConnect.js

const MONGODB_CONNECTION_STRING = "mongodb+srv://rapsan363:NshFqcRnuwloF96J@cluster0.mw6iqkn.mongodb.net/finaldbms?retryWrites=true&w=majority";
const dbConnect = async ()=>{
    try {
        if ((external_mongoose_default()).connection.readyState !== 1) {
            await external_mongoose_default().connect(MONGODB_CONNECTION_STRING, {
                useUnifiedTopology: true
            });
            console.log("Connected to MongoDB");
        }
    } catch (error) {
        console.error("Error connecting to MongoDB:", error.message);
    }
};
/* harmony default export */ const utils_dbConnect = (dbConnect);

;// CONCATENATED MODULE: external "validator"
const external_validator_namespaceObject = require("validator");
var external_validator_default = /*#__PURE__*/__webpack_require__.n(external_validator_namespaceObject);
;// CONCATENATED MODULE: ./models/newsletter.js


const NewsletterSchema = new (external_mongoose_default()).Schema({
    email: {
        type: String,
        required: true,
        unique: true,
        validate: {
            validator: (value)=>external_validator_default().isEmail(value),
            message: "Invalid email format"
        }
    },
    subscribedAt: {
        type: Date,
        default: Date.now
    }
});
const Newsletter = (external_mongoose_default()).models.Newsletter || external_mongoose_default().model("Newsletter", NewsletterSchema);
/* harmony default export */ const newsletter = (Newsletter);

;// CONCATENATED MODULE: ./pages/api/newsletters/index.js


async function handler(req, res) {
    await utils_dbConnect();
    switch(req.method){
        case "GET":
            try {
                const newsletters = await newsletter.find({});
                res.status(200).json({
                    newsletters
                });
            } catch (error) {
                res.status(500).json({
                    message: "Error fetching emails",
                    error: error.message
                });
            }
            break;
        case "POST":
            try {
                const { email  } = req.body;
                const newEmail = new newsletter({
                    email
                });
                await newEmail.save();
                res.status(201).json({
                    message: "Email saved successfully"
                });
            } catch (error1) {
                res.status(500).json({
                    message: "Error saving email",
                    error: error1.message
                });
            }
            break;
        default:
            res.status(405).json({
                message: "Method Not Allowed"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6219));
module.exports = __webpack_exports__;

})();