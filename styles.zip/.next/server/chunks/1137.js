exports.id = 1137;
exports.ids = [1137];
exports.modules = {

/***/ 2942:
/***/ ((module) => {

// Exports
module.exports = {
	"exploreContent": "ExploreSection_exploreContent__bPqL8",
	"exploreTitle": "ExploreSection_exploreTitle__DZSlu",
	"exploreDescription": "ExploreSection_exploreDescription__P_WAy"
};


/***/ }),

/***/ 1137:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ExploreSection_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2942);
/* harmony import */ var _ExploreSection_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ExploreSection_module_css__WEBPACK_IMPORTED_MODULE_2__);



const ExploreSection = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `price-plan-page-middle ${(_ExploreSection_module_css__WEBPACK_IMPORTED_MODULE_2___default().exploreSection)}`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `container ${(_ExploreSection_module_css__WEBPACK_IMPORTED_MODULE_2___default().exploreContainer)}`,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_ExploreSection_module_css__WEBPACK_IMPORTED_MODULE_2___default().exploreContent),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: (_ExploreSection_module_css__WEBPACK_IMPORTED_MODULE_2___default().exploreTitle),
                        children: "Explore Our Services"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: (_ExploreSection_module_css__WEBPACK_IMPORTED_MODULE_2___default().exploreDescription),
                        children: "Elevate your global standards with our comprehensive suite of services. Our expert team is dedicated to providing innovative solutions tailored to meet your unique challenges. Partner with us to transform your business, enhance security, and achieve unparalleled success on a global scale."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        legacyBehavior: true,
                        href: "/services",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                            className: "theme-btn mt-20 wow fadeInUp delay-0-6s",
                            children: [
                                "Explore ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fas fa-long-arrow-right"
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExploreSection);


/***/ })

};
;