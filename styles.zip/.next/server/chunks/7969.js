exports.id = 7969;
exports.ids = [7969];
exports.modules = {

/***/ 7969:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_datetime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(611);
/* harmony import */ var react_datetime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_datetime__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_datetime_css_react_datetime_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1600);
/* harmony import */ var react_datetime_css_react_datetime_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_datetime_css_react_datetime_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _forms_ContactForm__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2047);






const DateTimePicker = ()=>{
    const [selectedDate, setSelectedDate] = useState(null);
    const [selectedTime, setSelectedTime] = useState(null);
    const [appointmentDate, setAppointmentDate] = useState(null);
    const handleDateChange = (date)=>{
        setSelectedDate(date);
    };
    const handleTimeChange = (time)=>{
        setSelectedTime(time);
    };
    const handleBookAppointment = async ()=>{
        if (selectedDate && selectedTime) {
            const completeDateTime = new Date(selectedDate);
            completeDateTime.setHours(selectedTime.hours());
            completeDateTime.setMinutes(selectedTime.minutes());
            console.log("Appointment booked for:", completeDateTime);
            setAppointmentDate(completeDateTime);
            // Additional logic to handle booking can be added here
            // Reset the form
            setSelectedDate(null);
            setSelectedTime(null);
        } else {
            alert("Please select a valid date and time for the appointment.");
        }
    };
    return /*#__PURE__*/ _jsxs("div", {
        className: styles["datetime-picker-container"],
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: styles["date-picker"],
                children: /*#__PURE__*/ _jsx(Datetime, {
                    value: selectedDate,
                    onChange: handleDateChange,
                    inputProps: {
                        placeholder: "Select date",
                        readOnly: true
                    },
                    className: `${styles["appearance-none"]} ${styles["shadow"]} ${styles["border"]} ${styles["rounded"]} ${styles["text-gray-darker"]}`
                })
            }),
            /*#__PURE__*/ _jsx("div", {
                className: styles["time-picker"],
                children: /*#__PURE__*/ _jsx(Datetime, {
                    value: selectedTime,
                    onChange: handleTimeChange,
                    inputProps: {
                        placeholder: "Select time",
                        readOnly: true
                    },
                    dateFormat: false,
                    timeFormat: "HH:mm",
                    className: `${styles["appearance-none"]} ${styles["shadow"]} ${styles["border"]} ${styles["rounded"]} ${styles["text-gray-darker"]}`
                })
            }),
            /*#__PURE__*/ _jsx("button", {
                className: styles["book-appointment-btn"],
                onClick: handleBookAppointment,
                children: "Book Appointment"
            }),
            /*#__PURE__*/ _jsx(ContactForm, {
                appointmentDate: appointmentDate
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (DateTimePicker)));


/***/ }),

/***/ 1600:
/***/ (() => {



/***/ })

};
;