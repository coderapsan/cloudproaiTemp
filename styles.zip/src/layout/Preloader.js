const Preloader = () => {
  return (
    <div className="preloader">
      <div className="custom-loader" />
    </div>
  );
};
export default Preloader;
